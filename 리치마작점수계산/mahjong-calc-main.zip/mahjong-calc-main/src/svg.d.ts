declare module '*.svg' {
  const svg: React.FC<React.SVGProps<SVGElement>>;
  export default svg;
}
